const express = require('express');
const engine = require('ejs-locals');
const request = require('request')
const bodyParser = require('body-parser');
const dateTime = require('node-datetime')
const path = require('path');
const mysql = require('mysql');
const { setDefaultResultOrder } = require('dns');
const { syncBuiltinESMExports } = require('module');
const app = express();
const port = 8080;

var logged_on = false

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'user',
    password: 'password',
    database: 'student',
    port: 3307
});

connection.connect((err) => {
    if (err) throw err;
    console.log('connected to mysql')
})

app.use(express.json());
app.use(bodyParser.urlencoded({extended: false}));
app.engine('ejs', engine);
app.set('view engine', 'ejs');

let student = [{name: "Name", english: 0, math: 0, science: 0}]

app.get('/', (req, res) => {
    // if (logged_on === true) {
        res.render("pages/info", {student: student})
    // }
    // else {
        // res.render("pages/login")
    // }
});

app.post('/add_data', (req, res) => {
    let new_data = {student: req.body.student, 
                    english: req.body.english, 
                    math: req.body.math, 
                    science: req.body.science
    };
    let sql = `INSERT INTO student.student_data (name, english, math, science) VALUES ('${new_data.student}', ${parseInt(new_data.english)}, ${parseInt(new_data.math)}, ${parseInt(new_data.science)})`
    console.log(sql)

    connection.query(sql, (err, result) => {
                console.log("new data added")
            });
    res.redirect('/')
});

// Auth stuff, I couldn't make this work in time ;-;

// app.post('/login', (req, res) => {
//     let login_cred = {
//         username: req.body.username,
//         password: req.body.password
//     }

//     auth_url = 'http://auth:8100/validate'
//     console.log(login_cred)
//     console.log(logged_on)
//     let code = 0

//     request.post({headers: {'Content-Type' : 'application/json'},
//                             url: auth_url, 
//                             body: JSON.stringify(login_cred)},
//                             (err, res, body) => {
//                                 console.log(res.statusCode)
//                                 code = res.statusCode
//                             });

//     console.log(code)
//     if (code === 201){
//         setTrue()
//     }
//     res.redirect('/')
// })

// function setTrue(){
//     logged_on = true
// }

app.get('/delete', (req, res) => {
        connection.query("DROP TABLE student_data", function (err, result) {
            if (err) throw err;
        });
    res.redirect('/')
});

app.get('/create', (req, res) => {
        connection.query("CREATE TABLE student_data (name VARCHAR(100) NOT NULL, english INT NOT NULL, math INT NOT NULL, science INT NOT NULL, date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP)", function (err, result) {
            if (err) throw err;
        });
    res.redirect('/')
});

app.listen(port);