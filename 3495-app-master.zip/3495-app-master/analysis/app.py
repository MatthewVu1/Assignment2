import mysql.connector
import pymongo
import time
import sys

def update_data():
    try:
        mongodb_client = pymongo.MongoClient("mongodb://user:password@mongo:27017/")
        print('Connected to mongodb')
        mongodb_db = mongodb_client['summary']
    except:
        print('oopsie')
        exit()

    mysqldb = mysql.connector.connect(
        host="localhost",
        user="user",
        password="password",
        port=3307,
        database="student"
    )
    print('Updating data')
    mysql_cursor = mysqldb.cursor()

    mysql_cursor.execute("SELECT * FROM student_data")
    results = mysql_cursor.fetchall()

    english = []
    math = []
    science = []
    num_of_students = 0

    for i in results:
        english.append(i[1])
        math.append(i[2])
        science.append(i[3])
        num_of_students += 1

    # Calculate stats
    new_stats = {
        'num': num_of_students,
        'e_mean': sum(english) / len(english),
        'e_max': max(english),
        'e_min': min(english),
        'm_mean': sum(math) / len(math),
        'm_max': max(math),
        'm_min': min(math),
        's_mean': sum(science) / len(science),
        's_max': max(science),
        's_min': min(science)
    }    

    print(new_stats)
    # Insert into MongoDB
    x = mongodb_db.data.insert_one(new_stats)
    print(x.inserted_id)
    # mongodb_collection.find({}).sort({'_id':-1}).limit(1)

# update_data()
if __name__ == "__main__":
    while True:
        time.sleep(10)
        try:
            update_data()
        except:
            print("Unable to connect")