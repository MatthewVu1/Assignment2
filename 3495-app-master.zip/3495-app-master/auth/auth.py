import re
import connexion
from connexion import NoContent

valid = {
        'username': 'user',
        'password': 'password'
    }

def validate_cred(body):
    print(body)
    if body['username'] == valid['username']:
        if body['password'] == valid['password']:
            return NoContent, 201
        else:
            return NoContent, 400
    else:
        return NoContent, 400

app = connexion.FlaskApp(__name__, specification_dir='')
app.add_api("openapi.yaml", strict_validation=True, validate_responses=True)

if __name__ == "__main__":
    app.run(port=8100)