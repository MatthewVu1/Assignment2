const express = require('express');
const engine = require('ejs-locals');
const MongoClient = require('mongodb').MongoClient;
const path = require('path');
const app = express();
port = 8090

var url = 'mongodb://user:password@mongo:27017/'

app.use(express.json());
app.engine('ejs', engine);
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
    MongoClient.connect(url, function(err, db){
        console.log("Connected to mongodb")
        if (err) throw err;
        var dbo = db.db("summary");
        dbo.collection("data").find().limit(1).sort({ $natural: -1 }).toArray(function(err, item) {
            console.log(item)
            res.render('pages/index.ejs', {item: item[0]})
            db.close();
        });
    });
})

app.listen(port);